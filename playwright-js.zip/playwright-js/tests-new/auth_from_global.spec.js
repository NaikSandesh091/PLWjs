// @ts-check
const { test, expect } = require('@playwright/test');

test.describe("Authentication", ()=>{  

    test('authenticate Orange Hrm', async ({ page}) => {
        await page.goto('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login');
        const dashboard = await page.locator("//h6");
        console.log("sandesh",dashboard)
        await page.pause()
        await expect(dashboard).toHaveText("Dashboard")
    });

    test.only('auth secound', async ({ page}) => {
        await page.goto('https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewPersonalDetails/empNumber/7');
        const dashboard = await page.getByText("Personal");
        console.log("rajpal",dashboard)
        //await page.pause()
        //await expect(dashboard).toHaveText("Personal Details")
        await expect(dashboard).toBeVisible();
    });


});